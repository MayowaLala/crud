<?php
       
       include('../connection.php');
       include('../header.php');
	   include('../session.php'); 

$result=mysqli_query($db, "select * from users where user_id='$session_id'")or die('Error In Session');
$row=mysqli_fetch_array($result);
	   
	   
        ?>  
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">PerformanceSchool</a>
            </div>
     
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="#"><i class="fa fa-fw fa-dashboard"></i> Records</a>
						<a href="#"><i class="fa fa-fw fa-dashboard"></i> Tests</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Broadcast</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i>Payments</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Website CMS</a>
						<a href="../logout.php"><i class="fa fa-fw fa-dashboard"></i> Log Out</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <div id="page-wrapper">
<marquee><h3> Welcome, you are logged in as a teacher, we have some cool information for you</h3></marquee>

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                      
                        </h1>
                       
                    </div>
                </div>
                <!-- /.row -->


             <div class="col-lg-12">
          
		   <h3>Overview & Performance Analytics</h3>
		   <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Grade</th>
                                        <th>Number in Class</th>
                                        <th>Class Teacher</th>
                                    </tr>
                                </thead>
                                <tbody>
								<tr> 
								<td>Grade 1 </td>
								<td> 25 </td>
								<td> Oluwale Rasaq</td>
								</tr>
								<tr> 
								<td>Grade 2 </td>
								<td> 20 </td>
								<td> Chioma Victor</td>
								</tr>
		  </div>
<div>
 <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th>Overall Mean Score in all Classes</th>
                                    </tr>
                                </thead>
                                <tbody>
								<tr>
								<td> Mathematics</td>
								<td> 67 </td>
								</tr>
								<tr>
								<td> English Language</td>
								<td> 69 </td>
								</tr>
								<tr>
								<td> Basic Science</td>
								<td>  71</td>
								</tr>
								<tr>
								<td> Agricultural Science</td>
								<td> 70 </td>
								</tr>
								<tr>
								<td> Cultural and Creative Arts</td>
								<td> 79 </td>
								</tr>
								</div>
<br>		   


                        <div class="table-responsive">
                            
                               
							   
							   
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="..js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../js/plugins/morris/raphael.min.js"></script>
    <script src="../js/plugins/morris/morris.min.js"></script>
    <script src="../js/plugins/morris/morris-data.js"></script>

</body>

</html>
