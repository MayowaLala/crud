
<?php
       
       include('connection.php');
       include('header.php');
	   include('session.php'); 

$result=mysqli_query($db, "select * from users where user_id='$session_id'")or die('Error In Session');
$row=mysqli_fetch_array($result);
	   
	   
        ?>  
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">PerformanceSchool</a>
            </div>
     
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="home.php"><i class="fa fa-fw fa-dashboard"></i> Records</a>
						<a href="home.php"><i class="fa fa-fw fa-dashboard"></i> Tests</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Broadcast</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i>Payments</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Website CMS</a>
						<a href="logout.php"><i class="fa fa-fw fa-dashboard"></i> Log Out</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                        Admin Dashboard
                        </h1>
                       
                    </div>
                </div>
                <!-- /.row -->


             <div class="col-lg-12">
		   
		   <H2>
		   Database
		   </h2>
		   
		  
                             
								<tr>
		<a href="add.php?action=add" type="button" class="btn btn-xs btn-info">Add New</a>
		<a href="export.php" type="button" class="btn btn-xs btn-info">Export Data</a>
		<a href="import.php" type="button" class="btn btn-xs btn-info">Import Data</a>
		

                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Full Name</th>
                                        <th>Gender</th>
                                        <th>Grade</th>
                                        <th>Guardian Name</th>
                                        <th>Date Of Birth</th>
                                        <th>Nationality</th>
                                        <th>State of Origin</th>
										 <th>Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php                  
                $query = 'SELECT * FROM students';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<tr>';
                            echo '<td>'. $row['student_surName'].', &nbsp '. $row['student_firstName'].', &nbsp '. $row['student_lastName'].' </td>';
                            echo '<td>'. $row['student_gender'].'</td>';
                            echo '<td>'. $row['student_grade'].'</td>';
                            echo '<td>'. $row['student_parent_Name'].'</td>';
                            echo '<td>'. $row['student_dob'].'</td>';
                            echo '<td>'. $row['student_nationality'].'</td>';
							echo '<td>'. $row['student_soo'].'</td>';
							echo '<td>'. $row['student_address'].'</td>';
						
                            echo '<td> <a type="button" class="btn btn-xs btn-info" href="searchfrm.php?action=edit & id='.$row['student_id'] . '" > SEARCH </a> ';
                            echo ' <a  type="button" class="btn btn-xs btn-warning" href="edit.php?action=edit & id='.$row['student_id'] . '"> EDIT </a> ';
                            echo ' <a  type="button" class="btn btn-xs btn-danger" href="del.php?type=people&delete & id=' . $row['student_id'] . '">DELETE </a> </td>';
                            echo '</tr> ';
                }
            ?> 
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
