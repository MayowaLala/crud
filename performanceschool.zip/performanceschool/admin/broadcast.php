<?php
   
       include('header.php');
     
	   
        ?> 


<!DOCTYPE html>
 <head>
   <meta charset="utf-8" />
  </head>
  <body>
  
  <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Performance NG</a>
            </div>
     
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="home.php"><i class="fa fa-fw fa-dashboard"></i> Records</a>
						<a href="home.php"><i class="fa fa-fw fa-dashboard"></i> Tests</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Broadcast</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i>Payments</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Website CMS</a>
						<a href="logout.php"><i class="fa fa-fw fa-dashboard"></i> Log Out</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                         Membership Database
                        </h1>
                       
                    </div>
                </div>
             
    <form action="" method="post">
     <ul>
      <li>
       <label for="phoneNumber">Phone Number</label>
       <input type="text" name="phoneNumber" id="phoneNumber" placeholder="3855550168" /></li>
      <li>
      <label for="carrier">Carrier</label>
       <input type="text" name="carrier" id="carrier" />
      </li>
      <li>
       <label for="smsMessage">Message</label>
       <textarea name="smsMessage" id="smsMessage" cols="45" rows="15"></textarea>
      </li>
     <li><input type="submit" name="sendMessage" id="sendMessage" value="Send Message" /></li>
    </ul>
   </form>
  </div>


<?php
/*
mail($to_email_address,$subject,$message,[$headers],[$parameters]);

?>


</body>
</HTML>