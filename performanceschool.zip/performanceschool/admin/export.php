<?php
include('connection.php');
$query = 'SELECT * FROM people';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));

						while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<tr>';
                            echo '<td>'. $row['first_name'].'</td>';
                            echo '<td>'. $row['last_name'].'</td>';
                            echo '<td>'. $row['mid_name'].'</td>';
                            echo '<td>'. $row['address'].'</td>';
                            echo '<td>'. $row['contact'].'</td>';
                            echo '<td>'. $row['comment'].'</td>';
							}
$serialize_user_arr = serialize($row); 
echo $serialize_user_arr;
$filename = 'people.csv';

// file creation
$file = fopen($filename,"w");

fclose($file); 

// download
header("Content-Description: File Transfer");
header("Content-Disposition: attachment; filename=".$filename);
header("Content-Type: application/csv; "); 

readfile($filename);

// deleting file
unlink($filename);
exit();
