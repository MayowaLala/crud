<?php    

	 include('connection.php');
       include('header.php');
	   include('session.php');
?>
<body>

  <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">Performance NG</a>
            </div>
        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
						<a href="home.php"><i class="fa fa-fw fa-dashboard"></i> Records</a>
						<a href="home.php"><i class="fa fa-fw fa-dashboard"></i> Tests</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Broadcast</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i>Payments</a>
						<a href="broadcast.php"><i class="fa fa-fw fa-dashboard"></i> Website CMS</a>
						<a href="logout.php"><i class="fa fa-fw fa-dashboard"></i> Log Out</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
		
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Membership Database <small></small>
                        </h1>
                       
                    </div>
                </div>

            <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport"
                enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">Choose CSV
                        File</label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import"
                        class="btn-submit">Import</button>

                </div>

            </form>
	<?php
 
if ((isset($_POST["import"])) && $File = fopen($_FILES["file"]["tmp_name"], "r"))
  { 
	$n =	1; 
	while (($row = fgetcsv($File, 1000, ",")) !== FALSE) {
	$query = 'INSERT INTO imports (id, username, password, firstName, lastName )
	VALUES  ("'.$row[0].'", "'.$row[1].'", "'.$row[2].'" , "'.$row[3].'", "'.$row[4].'")';
	$result = mysqli_query($db, $query) or die (mysqli_error($db));}
			$n++;
		fclose($File);
		echo 'imported successfully';}
	?>
	
	     </div>

    </div>

</html>