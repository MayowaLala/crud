<?php session_start(); ?>
<?php include('connection.php'); ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<center><h2 color='black'>PerformanceSchool</h2></center>

<div class="form-wrapper">
  
  <form action="#" method="post">
    <h3>Login here</h3>
	
    <div class="form-item">
		<input type="text" name="user" required="required" placeholder="Username" autofocus required></input>
    </div>
    
    <div class="form-item">
		<input type="password" name="pass" required="required" placeholder="Password" required></input>
    </div>
    <div class="form-item"> Select User Type: 
		<select name="usertype" required="required">
		<option value= "superadmin">Super Admin </option>
		<option value= "admin">Admin</option>
		<option value= "teacher">Teacher </option>
		<option value= "student">Student </option>
		<option value= "parent">Parent</option>
		</select>
    </div>
    <div class="button-panel">
		<input type="submit" class="button" title="Log In" name="login" value="Login"></input>
    </div>
  </form>
  <?php
  
 
	if (isset($_POST['login']))
	{
			$username = mysqli_real_escape_string($db, $_POST['user']);
			$password = mysqli_real_escape_string($db, $_POST['pass']);
			$usertype = mysqli_real_escape_string($db, $_POST['usertype']);
			
		//select database program
		
			$query 		= mysqli_query($db, "SELECT * FROM users WHERE  password='$password' and username='$username' and usertype = '$usertype'");
			$row		= mysqli_fetch_array($query);
			$num_row 	= mysqli_num_rows($query);
			
			if ($num_row > 0)  
				{			
				if ($row['user_id'] == 1)
						{
						$_SESSION['user_id']=$row['user_id'];
					header('location:superadmin/index.php');
					}
				else if ($row['user_id'] == 2)
				{
						$_SESSION['user_id']=$row['user_id'];
					header('location:admin/index.php');
					}
				else if ($row['user_id'] == 3)
				{
						$_SESSION['user_id']=$row['user_id'];
					header('location:teacher/index.php');
					}
				else if ($row['user_id'] == 4)
				{
						$_SESSION['user_id']=$row['user_id'];
					header('location:student/index.php');
					}
				else 
				{
						$_SESSION['user_id']=$row['user_id'];
					header('location:parent/index.php');
					}
				}
			else
				{
					echo 'Invalid Username and Password Combination';
				}
		}
  ?>
  <div class="reminder">
    <p>Not a member? <a href="#">Sign up now</a></p>
    <p><a href="#">Forgot password?</a></p>
  </div>
  
</div>

</body>
</html>